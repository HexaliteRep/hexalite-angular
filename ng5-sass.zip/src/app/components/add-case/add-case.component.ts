import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

import { Case } from '../../model/Case';

import { BackendService } from '../../services/backend.service';

@Component({
  selector: 'app-add-case',
  templateUrl: './add-case.component.html',
  styleUrls: ['./add-case.component.scss']
})
export class AddCaseComponent implements OnInit {

  constructor(private location: Location,
    private backendService: BackendService) { }

  ngOnInit() {
  }

  addCase() {
    const caso = new Case (new Date(),
      'Towing',
      'Flat tyre',
      '9KWYR',
      'door num street name Vienna Vienna A 123456',
      'CARAVAN',
      new Date(),
      'ASG1518579392902',
      'ONDEMAND',
      'Provider Timeout'
    );
    this.backendService.addCase(caso)
      .subscribe(
        x => console.log('test'));
        const a = 1;
  }

  goBack() {
    this.location.back();
  }

}
