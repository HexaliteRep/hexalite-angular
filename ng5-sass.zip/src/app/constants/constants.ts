export class Constants {

  public static SERVICE_TYPE = [{
    id: '1',
    name: 'Jumpstart',
    value: '1'
  },
  {
    id: '2',
    name: 'Repair on spot',
    value: '2'
  },
  {
    id: '3',
    name: 'Towing',
    value: '3'
  },
  {
    id: '4',
    name: 'Accompany to repair',
    value: '4'
  },
  {
    id: '5',
    name: 'Towing needed',
    value: '5'
  }];

  public static EVENT_TYPE = [{
    id: '1',
    name: 'All',
    value: '1'
  },
  {
    id: '2',
    name: 'Flat tyre',
    value: '2'
  },
  {
    id: '3',
    name: 'Flat battery',
    value: '3'
  },
  {
    id: '4',
    name: 'No fuel',
    value: '4'
  },
  {
    id: '5',
    name: 'Wrong fuel',
    value: '5'
  },
  {
    id: '6',
    name: 'Lockout',
    value: '6'
  },
  {
    id: '7',
    name: 'Breakdown',
    value: '7'
  }];

  public static STATUS = [{
    _id: '1',
    name: 'Provider acceptance pending',
    value: '1'
  },
  {
    _id: '2',
    name: 'Provider Timeout',
    value: '2'
  }];
}
