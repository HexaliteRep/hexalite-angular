import { LatLng } from '@agm/core';

export  class Waypoint {
  constructor(
      public location?: google.maps.LatLng
  ) { }
}
