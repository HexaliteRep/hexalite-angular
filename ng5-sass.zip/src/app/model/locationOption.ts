export  class LocationOption  {
  constructor(
      public  id?: number,
      public  name?:  string,
      public lat?: number,
      public lng?: number,
  ) { }
}
